package com.example.employeemanagementsystem.projection;

public interface EmployeeProjection {

    // Only return the id and name of the employee
    Long getId();
    String getName();
}
