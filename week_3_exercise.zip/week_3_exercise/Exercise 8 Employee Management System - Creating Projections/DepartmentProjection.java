package com.example.employeemanagementsystem.projection;

public interface DepartmentProjection {

    // Only return the id and name of the department
    Long getId();
    String getName();
}
