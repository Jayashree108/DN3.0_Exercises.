package com.example.employeemanagementsystem.controller;

import com.example.employeemanagementsystem.entity.Employee;
import com.example.employeemanagementsystem.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    // Paginated and sorted retrieval of employees by name
    @GetMapping("/search")
    public Page<Employee> getEmployeesByName(
            @RequestParam(required = false) String name,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "name") String sortBy) {
        return employeeService.getEmployeesByName(name, page, size, sortBy);
    }

    // Paginated and sorted retrieval of employees by email
    @GetMapping("/searchByEmail")
    public Page<Employee> getEmployeesByEmail(
            @RequestParam(required = false) String email,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "name") String sortBy) {
        return employeeService.getEmployeesByEmail(email, page, size, sortBy);
    }

    // Paginated and sorted retrieval of employees by department ID
    @GetMapping("/searchByDepartment")
    public Page<Employee> getEmployeesByDepartmentId(
            @RequestParam Long departmentId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "name") String sortBy) {
        return employeeService.getEmployeesByDepartmentId(departmentId, page, size, sortBy);
    }
}
