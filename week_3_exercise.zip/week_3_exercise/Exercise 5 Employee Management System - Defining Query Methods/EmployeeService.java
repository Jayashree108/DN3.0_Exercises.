package com.example.employeemanagementsystem.service;

import com.example.employeemanagementsystem.entity.Employee;
import com.example.employeemanagementsystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @PersistenceContext
    private EntityManager entityManager;

    public List<Employee> getEmployeesByName(String name) {
        TypedQuery<Employee> query = entityManager.createNamedQuery("Employee.findByName", Employee.class);
        query.setParameter("name", name);
        return query.getResultList();
    }

    public List<Employee> getEmployeesByEmail(String email) {
        TypedQuery<Employee> query = entityManager.createNamedQuery("Employee.findByEmail", Employee.class);
        query.setParameter("email", email);
        return query.getResultList();
    }

    public List<Employee> getEmployeesByDepartmentId(Long departmentId) {
        TypedQuery<Employee> query = entityManager.createNamedQuery("Employee.findByDepartmentId", Employee.class);
        query.setParameter("departmentId", departmentId);
        return query.getResultList();
    }
}
