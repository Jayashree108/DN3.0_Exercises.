package com.example.employeemanagementsystem.repository;

import com.example.employeemanagementsystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface employeeRepository extends JpaRepository<Employee, Long> {

    // Custom query using JPQL to find employees by name
    @Query("SELECT e FROM Employee e WHERE e.name = :name")
    List<Employee> findEmployeesByName(@Param("name") String name);

    // Custom query using native SQL to find employees by email
    @Query(value = "SELECT * FROM employees WHERE email = :email", nativeQuery = true)
    List<Employee> findEmployeesByEmail(@Param("email") String email);

    // Custom query to find employees with salary greater than a specified amount
    @Query("SELECT e FROM Employee e WHERE e.salary > :salary")
    List<Employee> findEmployeesWithSalaryGreaterThan(@Param("salary") Double salary);
}
