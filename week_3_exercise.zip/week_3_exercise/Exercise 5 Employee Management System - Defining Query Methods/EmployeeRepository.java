package com.example.employeemanagementsystem.repository;

import com.example.employeemanagementsystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Find employees by their name
    List<Employee> findByName(String name);

    // Find employees by their email
    List<Employee> findByEmail(String email);

    // Find employees by their department's id
    List<Employee> findByDepartmentId(Long departmentId);

    // Find employees whose salary is greater than a specified amount
    List<Employee> findBySalaryGreaterThan(Double salary);
}
