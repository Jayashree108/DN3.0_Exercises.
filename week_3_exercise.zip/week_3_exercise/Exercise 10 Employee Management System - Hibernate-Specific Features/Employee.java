package com.example.employeemanagementsystem.entity;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "employees")
@Data
public class Employee {

    @Id
    @GeneratedValue(generator = "custom-id-generator")
    @GenericGenerator(name = "custom-id-generator", strategy = "uuid2")
    private String id;

    private String name;

    private String email;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id")
    private Department department;

    @Column(name = "created_date")
    @Type(type = "org.hibernate.type.LocalDateTimeType")
    private LocalDateTime createdDate;

    @Column(name = "last_modified_date")
    @Type(type = "org.hibernate.type.LocalDateTimeType")
    private LocalDateTime lastModifiedDate;

    @Column(name = "status")
    @Type(type = "org.hibernate.type.StringType")
    private String status; // Custom type example
}
