import java.util.Arrays;

public class BinarySearch {
    public static Product binarySearch(Product[] products, String productName) {
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getProductName().compareTo(productName);

            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Product[] products = {
                new Product("001", "Product1", "Category1"),
                new Product("002", "Product2", "Category1"),
                new Product("003", "Product3", "Category2"),
                new Product("004", "Product4", "Category2")
        };

        // Sort products by productName for binary search
        Arrays.sort(products, (p1, p2) -> p1.getProductName().compareTo(p2.getProductName()));

        // Linear Search
        Product result1 = LinearSearch.linearSearch(products, "Product3");
        System.out.println("Linear Search Result: " + result1);

        // Binary Search
        Product result2 = BinarySearch.binarySearch(products, "Product3");
        System.out.println("Binary Search Result: " + result2);
    }
}
