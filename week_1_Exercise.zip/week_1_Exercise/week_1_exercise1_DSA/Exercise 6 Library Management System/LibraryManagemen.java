import java.util.Collections;
import java.util.Comparator;

public class LibraryManagement {
    private List<Book> books;

    public LibraryManagement() {
        this.books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
        // Ensure the list is sorted after adding a new book
        Collections.sort(books, Comparator.comparing(Book::getTitle));
    }

    public Book binarySearchByTitle(String title) {
        int left = 0;
        int right = books.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            Book midBook = books.get(mid);

            if (midBook.getTitle().equalsIgnoreCase(title)) {
                return midBook;
            }

            if (midBook.getTitle().compareToIgnoreCase(title) < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public void displayBooks() {
        for (Book book : books) {
            System.out.println(book);
        }
    }

    public static void main(String[] args) {
        LibraryManagement library = new LibraryManagement();
        library.addBook(new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"));
        library.addBook(new Book(2, "1984", "George Orwell"));
        library.addBook(new Book(3, "To Kill a Mockingbird", "Harper Lee"));

        System.out.println("Library Books:");
        library.displayBooks();

        System.out.println("\nBinary Search for '1984':");
        Book foundBook = library.binarySearchByTitle("1984");
        if (foundBook != null) {
            System.out.println("Found: " + foundBook);
        } else {
            System.out.println("Book not found.");
        }
    }
}
