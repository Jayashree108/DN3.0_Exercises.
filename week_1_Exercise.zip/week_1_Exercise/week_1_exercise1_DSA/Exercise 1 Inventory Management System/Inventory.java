import java.util.HashMap;
import java.util.Map;

public class Inventory {
    private Map<String, Product> products;

    public Inventory() {
        this.products = new HashMap<>();
    }

    public void addProduct(Product product) {
        if (products.containsKey(product.getProductId())) {
            throw new IllegalArgumentException("Product with this ID already exists.");
        }
        products.put(product.getProductId(), product);
    }

    public void updateProduct(String productId, String productName, Integer quantity, Double price) {
        if (!products.containsKey(productId)) {
            throw new IllegalArgumentException("Product not found.");
        }
        Product product = products.get(productId);
        if (productName != null) {
            product.setProductName(productName);
        }
        if (quantity != null) {
            product.setQuantity(quantity);
        }
        if (price != null) {
            product.setPrice(price);
        }
    }

    public void deleteProduct(String productId) {
        if (!products.containsKey(productId)) {
            throw new IllegalArgumentException("Product not found.");
        }
        products.remove(productId);
    }

    @Override
    public String toString() {
        return "Inventory{" +
                "products=" + products +
                '}';
    }

    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        // Add products
        Product p1 = new Product("001", "Product1", 10, 100.0);
        Product p2 = new Product("002", "Product2", 20, 200.0);
        inventory.addProduct(p1);
        inventory.addProduct(p2);

        // Update a product
        inventory.updateProduct("001", "UpdatedProduct1", 15, 150.0);

        // Delete a product
        inventory.deleteProduct("002");

        // Print inventory
        System.out.println(inventory);
    }
}
