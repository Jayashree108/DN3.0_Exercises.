public class FinancialForecasting {

    // Recursive method to calculate future value
    public static double calculateFutureValue(double principal, double rate, int periods) {
        // Base case: If no periods are left, return the principal
        if (periods == 0) {
            return principal;
        }
        // Recursive case: Compute future value for the next period
        return calculateFutureValue(principal * (1 + rate), rate, periods - 1);
    }

    public static void main(String[] args) {
        double principal = 1000.0; // Initial amount
        double rate = 0.05; // 5% annual growth rate
        int periods = 10; // Number of years

        double futureValue = calculateFutureValue(principal, rate, periods);
        System.out.println("Future Value: " + futureValue);
    }
}
