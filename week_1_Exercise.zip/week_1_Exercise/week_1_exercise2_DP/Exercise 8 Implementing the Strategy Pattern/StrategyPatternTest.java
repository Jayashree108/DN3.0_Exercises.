public class StrategyPatternTest {
    public static void main(String[] args) {
        // Create a payment strategy for credit card
        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9876-5432", "John Doe", "123");
        PaymentContext context1 = new PaymentContext(creditCardPayment);
        context1.executePayment(100.00);

        // Create a payment strategy for PayPal
        PaymentStrategy payPalPayment = new PayPalPayment("john.doe@example.com");
        PaymentContext context2 = new PaymentContext(payPalPayment);
        context2.executePayment(200.00);
    }
}
