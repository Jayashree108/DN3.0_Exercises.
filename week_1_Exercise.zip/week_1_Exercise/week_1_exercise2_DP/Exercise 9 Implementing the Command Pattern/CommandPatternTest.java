public class CommandPatternTest {
    public static void main(String[] args) {
        // Create a Light (receiver) instance
        Light light = new Light();

        // Create concrete command instances
        Command lightOn = new LightOnCommand(light);
        Command lightOff = new LightOffCommand(light);

        // Create RemoteControl (invoker) instance
        RemoteControl remote = new RemoteControl();

        // Turn the light on
        remote.setCommand(lightOn);
        remote.pressButton();

        // Turn the light off
        remote.setCommand(lightOff);
        remote.pressButton();
    }
}
