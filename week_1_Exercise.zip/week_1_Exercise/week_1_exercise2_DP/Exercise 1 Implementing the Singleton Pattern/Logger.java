public class Logger {
    // Step 1: Create a private static instance of the class
    private static Logger instance;

    // Step 2: Make the constructor private so that this class cannot be instantiated from outside
    private Logger() {
        // Optional: Initialize resources here, if necessary
    }

    // Step 3: Provide a public static method to get the instance of the class
    public static Logger getInstance() {
        // Create the instance if it does not exist
        if (instance == null) {
            synchronized (Logger.class) {
                if (instance == null) {
                    instance = new Logger();
                }
            }
        }
        return instance;
    }

    // Example method for logging
    public void log(String message) {
        System.out.println("Log message: " + message);
    }
}
