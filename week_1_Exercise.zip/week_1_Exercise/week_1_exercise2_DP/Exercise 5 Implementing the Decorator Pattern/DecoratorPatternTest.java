public class DecoratorPatternTest {
    public static void main(String[] args) {
        // Create a base email notifier
        Notifier emailNotifier = new EmailNotifier();

        // Decorate email notifier with SMS functionality
        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier);
        smsNotifier.send("Hello via Email and SMS!");

        // Decorate email notifier with Slack functionality
        Notifier slackNotifier = new SlackNotifierDecorator(emailNotifier);
        slackNotifier.send("Hello via Email and Slack!");

        // Combine multiple decorators
        Notifier combinedNotifier = new SlackNotifierDecorator(new SMSNotifierDecorator(emailNotifier));
        combinedNotifier.send("Hello via Email, SMS, and Slack!");
    }
}
