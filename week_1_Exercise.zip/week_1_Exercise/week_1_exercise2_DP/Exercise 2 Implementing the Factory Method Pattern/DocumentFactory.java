public abstract class DocumentFactory {
    // Factory method
    public abstract Document createDocument();
}
