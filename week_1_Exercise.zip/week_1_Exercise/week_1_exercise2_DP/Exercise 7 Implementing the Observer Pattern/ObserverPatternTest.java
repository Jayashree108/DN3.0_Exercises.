public class ObserverPatternTest {
    public static void main(String[] args) {
        // Create a StockMarket (subject) instance
        StockMarket stockMarket = new StockMarket();

        // Create observer instances
        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();

        // Register observers with the stock market
        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        // Update stock price (this will notify all registered observers)
        System.out.println("Setting stock price to $150.00");
        stockMarket.setStockPrice(150.00);

        // Deregister one observer
        stockMarket.deregisterObserver(mobileApp);

        // Update stock price again
        System.out.println("Setting stock price to $175.00");
        stockMarket.setStockPrice(175.00);
    }
}
