public class Computer {
    // Required parameters
    private final String CPU;
    
    // Optional parameters
    private final String RAM;
    private final String storage;
    private final String GPU;
    private final boolean isBluetoothEnabled;

    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
        this.GPU = builder.GPU;
        this.isBluetoothEnabled = builder.isBluetoothEnabled;
    }

    @Override
    public String toString() {
        return "Computer{" +
                "CPU='" + CPU + '\'' +
                ", RAM='" + RAM + '\'' +
                ", Storage='" + storage + '\'' +
                ", GPU='" + GPU + '\'' +
                ", Bluetooth Enabled=" + isBluetoothEnabled +
                '}';
    }

    // Static nested Builder class
    public static class Builder {
        // Required parameters
        private final String CPU;
        
        // Optional parameters
        private String RAM = "8GB"; // default value
        private String storage = "256GB SSD"; // default value
        private String GPU = "Integrated"; // default value
        private boolean isBluetoothEnabled = false; // default value

        public Builder(String CPU) {
            this.CPU = CPU;
        }

        public Builder RAM(String RAM) {
            this.RAM = RAM;
            return this;
        }

        public Builder storage(String storage) {
            this.storage = storage;
            return this;
        }

        public Builder GPU(String GPU) {
            this.GPU = GPU;
            return this;
        }

        public Builder bluetoothEnabled(boolean isBluetoothEnabled) {
            this.isBluetoothEnabled = isBluetoothEnabled;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }
}
