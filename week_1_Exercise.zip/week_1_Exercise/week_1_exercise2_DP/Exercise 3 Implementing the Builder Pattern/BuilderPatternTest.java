public class BuilderPatternTest {
    public static void main(String[] args) {
        // Create a Computer with default values
        Computer basicComputer = new Computer.Builder("Intel i5").build();
        System.out.println("Basic Computer: " + basicComputer);

        // Create a Computer with custom values
        Computer advancedComputer = new Computer.Builder("Intel i9")
                .RAM("16GB")
                .storage("1TB SSD")
                .GPU("NVIDIA GTX 3080")
                .bluetoothEnabled(true)
                .build();
        System.out.println("Advanced Computer: " + advancedComputer);
    }
}
