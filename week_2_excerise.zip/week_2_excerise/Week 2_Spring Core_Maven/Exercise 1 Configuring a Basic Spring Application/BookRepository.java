package com.library.repository;

public class BookRepository {

    public void printRepositoryInfo() {
        System.out.println("BookRepository is running");
        // You can add more repository methods here
    }
}
