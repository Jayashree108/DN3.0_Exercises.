CREATE OR REPLACE PROCEDURE TransferFunds (
    p_source_account_id IN NUMBER,
    p_destination_account_id IN NUMBER,
    p_amount IN NUMBER
) AS
    v_source_balance Accounts.Balance%TYPE;
BEGIN
    -- Check if the source account has sufficient balance
    SELECT Balance INTO v_source_balance
    FROM Accounts
    WHERE AccountID = p_source_account_id;

    IF v_source_balance < p_amount THEN
        RAISE_APPLICATION_ERROR(-20001, 'Insufficient balance in source account.');
    ELSE
        -- Deduct amount from source account
        UPDATE Accounts
        SET Balance = Balance - p_amount
        WHERE AccountID = p_source_account_id;

        -- Add amount to destination account
        UPDATE Accounts
        SET Balance = Balance + p_amount
        WHERE AccountID = p_destination_account_id;
        
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Transferred ' || p_amount || ' from account ID ' || p_source_account_id ||
                             ' to account ID ' || p_destination_account_id);
    END IF;
END;
/
