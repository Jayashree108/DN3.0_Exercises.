CREATE OR REPLACE PROCEDURE SafeTransferFunds(
    p_from_account_id IN NUMBER,
    p_to_account_id IN NUMBER,
    p_amount IN NUMBER
) AS
    v_from_balance Accounts.Balance%TYPE;
    v_to_balance Accounts.Balance%TYPE;
BEGIN
    -- Start a transaction
    SAVEPOINT transfer_start;

    -- Check current balance of the from account
    SELECT Balance INTO v_from_balance
    FROM Accounts
    WHERE AccountID = p_from_account_id;

    -- Ensure sufficient funds
    IF v_from_balance < p_amount THEN
        RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds in account ' || p_from_account_id);
    END IF;

    -- Get the balance of the to account
    SELECT Balance INTO v_to_balance
    FROM Accounts
    WHERE AccountID = p_to_account_id;

    -- Perform the transfer
    UPDATE Accounts
    SET Balance = v_from_balance - p_amount
    WHERE AccountID = p_from_account_id;

    UPDATE Accounts
    SET Balance = v_to_balance + p_amount
    WHERE AccountID = p_to_account_id;

    -- Commit the transaction
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Transfer of ' || p_amount || ' from account ' || p_from_account_id || ' to account ' || p_to_account_id || ' completed successfully.');

EXCEPTION
    WHEN OTHERS THEN
        -- Rollback to the savepoint if an error occurs
        ROLLBACK TO transfer_start;
        DBMS_OUTPUT.PUT_LINE('Error occurred: ' || SQLERRM);
END SafeTransferFunds;
/
