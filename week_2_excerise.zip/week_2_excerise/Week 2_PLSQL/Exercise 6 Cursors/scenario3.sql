DECLARE
    CURSOR c_loans IS
        SELECT LoanID, InterestRate
        FROM Loans;

    v_loanID Loans.LoanID%TYPE;
    v_currentInterestRate Loans.InterestRate%TYPE;
    v_newInterestRate NUMBER;
BEGIN
    FOR r_loan IN c_loans LOOP
        v_loanID := r_loan.LoanID;
        v_currentInterestRate := r_loan.InterestRate;

        -- Apply the new policy to update the interest rate
        -- Example policy: Increase interest rate by 0.5%
        v_newInterestRate := v_currentInterestRate + 0.5;

        UPDATE Loans
        SET InterestRate = v_newInterestRate
        WHERE LoanID = v_loanID;

        -- Print confirmation (or use DBMS_OUTPUT.PUT_LINE for logging purposes)
        DBMS_OUTPUT.PUT_LINE('Loan ID: ' || v_loanID || ' - New Interest Rate: ' || v_newInterestRate);
    END LOOP;
END;
/
