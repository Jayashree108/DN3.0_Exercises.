DECLARE
    CURSOR c_accounts IS
        SELECT AccountID, Balance
        FROM Accounts;

    v_accountID Accounts.AccountID%TYPE;
    v_balance Accounts.Balance%TYPE;
    v_fee NUMBER := 50; -- Annual maintenance fee
BEGIN
    FOR r_account IN c_accounts LOOP
        v_accountID := r_account.AccountID;
        v_balance := r_account.Balance;

        -- Deduct the annual fee from the account balance
        UPDATE Accounts
        SET Balance = v_balance - v_fee, LastModified = SYSDATE
        WHERE AccountID = v_accountID;

        -- Print confirmation (or use DBMS_OUTPUT.PUT_LINE for logging purposes)
        DBMS_OUTPUT.PUT_LINE('Account ID: ' || v_accountID || ' - Fee Applied: ' || v_fee);
    END LOOP;
END;
/
