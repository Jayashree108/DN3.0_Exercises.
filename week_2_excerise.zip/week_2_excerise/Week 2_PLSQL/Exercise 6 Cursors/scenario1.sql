DECLARE
    CURSOR c_transactions IS
        SELECT DISTINCT c.CustomerID, c.Name, t.TransactionDate, t.Amount, t.TransactionType
        FROM Transactions t
        JOIN Accounts a ON t.AccountID = a.AccountID
        JOIN Customers c ON a.CustomerID = c.CustomerID
        WHERE EXTRACT(MONTH FROM t.TransactionDate) = EXTRACT(MONTH FROM SYSDATE)
          AND EXTRACT(YEAR FROM t.TransactionDate) = EXTRACT(YEAR FROM SYSDATE);

    v_customerID Customers.CustomerID%TYPE;
    v_name Customers.Name%TYPE;
    v_transactionDate Transactions.TransactionDate%TYPE;
    v_amount Transactions.Amount%TYPE;
    v_transactionType Transactions.TransactionType%TYPE;
BEGIN
    FOR r_transaction IN c_transactions LOOP
        v_customerID := r_transaction.CustomerID;
        v_name := r_transaction.Name;
        v_transactionDate := r_transaction.TransactionDate;
        v_amount := r_transaction.Amount;
        v_transactionType := r_transaction.TransactionType;

        -- Print the statement (or use DBMS_OUTPUT.PUT_LINE for logging purposes)
        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || v_customerID || ', Name: ' || v_name ||
                             ', Date: ' || v_transactionDate || ', Amount: ' || v_amount ||
                             ', Type: ' || v_transactionType);
    END LOOP;
END;
/
