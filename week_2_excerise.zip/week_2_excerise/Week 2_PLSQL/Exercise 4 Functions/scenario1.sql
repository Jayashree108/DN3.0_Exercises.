CREATE OR REPLACE FUNCTION CalculateAge (p_dob DATE) RETURN NUMBER IS
    v_age NUMBER;
BEGIN
    -- Calculate age based on the date of birth
    v_age := FLOOR((SYSDATE - p_dob) / 365);
    RETURN v_age;
END;
/
