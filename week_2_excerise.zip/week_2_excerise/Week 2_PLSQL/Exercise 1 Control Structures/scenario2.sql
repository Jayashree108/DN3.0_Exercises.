DECLARE
    CURSOR c_customers IS
        SELECT CustomerID, Balance
        FROM Customers
        WHERE Balance > 10000;
BEGIN
    FOR rec IN c_customers LOOP
        -- Update VIP status for qualifying customers
        UPDATE Customers
        SET IsVIP = 'Y'
        WHERE CustomerID = rec.CustomerID;
        
        DBMS_OUTPUT.PUT_LINE('Promoted to VIP status for customer ID: ' || rec.CustomerID);
    END LOOP;
    
    COMMIT;
END;
