DECLARE
    CURSOR c_due_loans IS
        SELECT LoanID, CustomerID, EndDate
        FROM Loans
        WHERE EndDate BETWEEN SYSDATE AND SYSDATE + 30;
BEGIN
    FOR rec IN c_due_loans LOOP
        -- Print a reminder message
        DBMS_OUTPUT.PUT_LINE('Reminder: Loan ID ' || rec.LoanID ||
                             ' for customer ID ' || rec.CustomerID ||
                             ' is due on ' || rec.EndDate);
    END LOOP;
END;
