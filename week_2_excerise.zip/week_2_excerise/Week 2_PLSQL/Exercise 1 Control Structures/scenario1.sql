DECLARE
    CURSOR c_customers IS
        SELECT CustomerID, DOB
        FROM Customers
        WHERE EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM DOB) > 60;
        
    v_current_rate Loans.InterestRate%TYPE;
BEGIN
    FOR rec IN c_customers LOOP
        -- Fetch the current interest rate for the customer
        FOR loan_rec IN (
            SELECT InterestRate
            FROM Loans
            WHERE CustomerID = rec.CustomerID
        ) LOOP
            v_current_rate := loan_rec.InterestRate;
            
            -- Update interest rate with 1% discount
            UPDATE Loans
            SET InterestRate = v_current_rate - (v_current_rate * 0.01)
            WHERE CustomerID = rec.CustomerID;
        END LOOP;
        
        DBMS_OUTPUT.PUT_LINE('Applied discount to customer ID: ' || rec.CustomerID);
    END LOOP;
    
    COMMIT;
END;
